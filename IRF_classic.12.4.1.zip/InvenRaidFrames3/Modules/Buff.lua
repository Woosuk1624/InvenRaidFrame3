﻿local _G = _G
local next = _G.next
local pairs = _G.pairs
local ipairs = _G.ipairs
local select = _G.select
local tinsert = _G.table.insert
local wipe = _G.wipe
local UnitBuff = _G.UnitBuff
local GetSpellInfo = _G.GetSpellInfo
local IsSpellKnown = _G.IsSpellKnown
local UnitIsPlayer = _G.UnitIsPlayer
local UnitInVehicle = _G.UnitInVehicle
local IRF3 = _G[...]

if not UnitInVehicle then
	UnitInVehicle = function(unit) return false end
end

IRF3.raidBuffData = {}

function InvenRaidFrames3Member_UpdateBuffs()

end

function IRF3:SetupClassBuff()

	self.SetupClassBuff = nil
	InvenRaidFrames3CharDB.classBuff = nil
	InvenRaidFrames3CharDB.classBuff2 = type(InvenRaidFrames3CharDB.classBuff2) == "table" and InvenRaidFrames3CharDB.classBuff2 or {}

end

local playerClass = select(2, UnitClass("player"))

local classRaidBuffs = ({
	WARRIOR = {
		[6673] = { 1 },		-- [전사] 전투의 외침 (Legit 8.0)
	},
	ROGUE = {
	},
	PRIEST = {
		[21562] = { 2 },	-- 신의 권능: 인내 (Legit 8.0)
	},
	MAGE = {
		[1459] = { 3 },		-- 신비한 총명함 (Legit 8.0)
	},
	WARLOCK = {
	},
	HUNTER = {
	},
	DRUID = {
	},
	SHAMAN = {
	},
	PALADIN = {
	},
	DEATHKNIGHT = {
	},
	MONK = {
	},
	DEMONHUNTER = {
	},
})[playerClass]

local classicClassRaidBuff = ({
	WARRIOR = {
		[2048] = { 1 },		-- [전사] 전투의 외침 2048

	},
	ROGUE = {
	},
	PRIEST = {
		[1243] = { 2 },	-- 신의 권능: 인내 1244 1245 2791 10937 10938
--~ 		[21562] = { 2 },	-- 인내의 기원 21564
		[14752] = { 7 },	-- 천상의 정신
--~ 		[27681] = { 7 },	-- 정신력의 기원
		[976] = { 8 } , --암흑보호의 기원
	},
	MAGE = {
		[1459] = { 3 },		-- 신비한 지능
--~ 		[23028] = { 3 },		-- 신비한 총명함 (Legit 8.0)
	},
	WARLOCK = {
	},
	HUNTER = {
	},
	DRUID = {
		[1126] = { 5 },	-- 야생의 징표
--~ 		[21849] = { 5 },	-- 야생의 선물
		[467] = { 6 },		-- [드루이드] 가시
	},
	SHAMAN = {
	},
	PALADIN = {
		[1022]  = { 4 },	-- 보호의 축복 +
		[1038]  = { 4 },	-- 구원의 축복
		[1044]  = { 4 },	-- 자유의 축복
		[6940]  = { 4 },	-- 희생의 축복 +
		[19740] = { 4 },	-- 힘의 축복 +
		[19742] = { 4 },	-- 지혜의 축복 +
		[19977]  = { 4 },	-- 빛의 축복 +
		[20217]  = { 4 },	-- 왕의 축복 +
		[20911]  = { 4 },	-- 성역의 축복 +
--~ 		[25782] = { 4 },	-- 상급 힘의 축복 +
--~ 		[25890]  = { 4 },	-- 상급 빛의 축복 +
--~ 		[25894] = { 4 },	-- 상급 지혜의 축복 +
--~ 		[25895]  = { 4 },	-- 상급 구원의 축복
--~ 		[25898] = { 4 },	-- 상급 왕의 축복 +
--~ 		[25899]  = { 4 },	-- 상급 성역의 축복 +
	},
	DEATHKNIGHT = {
	},
	MONK = {
	},
	DEMONHUNTER = {
	},
})[playerClass]

if IRF3.isClassic then
	wipe(classRaidBuffs)
	classRaidBuffs = classicClassRaidBuff
end

if not classRaidBuffs then return end

local raidBuffs = {
	-- 전투력
	[1] = {
		6673,		-- [전사] 전투의 외침 (Legit 8.0)
	},
	-- 체력
	[2] = {
		21562,		-- [사제] 신의 권능: 인내 (Legit 8.0)
	},
	-- 지능
	[3] = {
		1459,		-- [마법사] 신비한 총명함 (Legit 8.0)
	},
--~ 	-- 왕축
--~ 	[4] = {
--~ 		203538,		-- [성기사] 상급 왕의 축복
--~ 	},
--~ 	-- 지축
--~ 	[5] = {
--~ 		203539,		-- [성기사] 상급 지혜의 축복
--~ 	},
}

local classicRaidBuffs = {

	-- 전투력
	[1] = {
		2048,		-- [전사] 전투의 외침 (Legit 8.0)
		5242,
	},
	-- 체력
	[2] = {
		1243,		-- [사제] 신의 권능: 인내 (Legit 8.0)
--~  		21562,		-- [사제] 인내의 기원
	},
	-- 지능
	[3] = {
		1459,		-- [마법사] 신비한 지능
--~ 		23028,		-- [마법사] 신비한 총명함 (Legit 8.0)
	},
	-- 왕축
	[4] = {
		1022,		-- [성기사] 보호의 축복
		1038,		-- [성기사] 구원의 축복
		1044,		-- [성기사] 자유의 축복
		6940,		-- [성기사] 희생의 축복
		19740,	-- [성기사] 힘의 축복
		19742,	-- [성기사] 지혜의 축복
		19977,	-- [성기사] 빛의 축복
		20217,	-- [성기사] 왕의 축복
		20911,	-- [성기사] 성역의 축복
--~ 		25782,	-- [성기사] 상급 힘의 축복
--~ 		25890,	-- [성기사] 상급 빛의 축복
--~ 		25894,	-- [성기사] 상급 지혜 축복
--~ 		25895,	-- [성기사] 상급 구원 축복
--~ 		25898,	-- [성기사] 상급 왕의 축복
--~ 		25899,	-- [성기사] 상급 성역 축복
	},
	-- 야징
	[5] = {
		1126,		-- [드루이드] 야생의 징표
--~ 		21849,		-- [드루이드] 야생의 선물
	},
	[6] = {
		467,		-- [드루이드] 가시
	},
	[7] = {
		14752,		-- [사제] 천상의 정신
--~  		27681,		-- [사제] 정신력의 기원
	},
	[8] = {
		976, 		-- [사제] 암흑보호
		27683, 		-- [사제] 암흑보호 기원
	}
}

if IRF3.isClassic then
	wipe(raidBuffs)
	raidBuffs = classicRaidBuffs
end

local sameBuffs = {
	--[1459] = 61316,	-- 신비한 총명함 = 달라란의 총명함
}

local classicSameBuffs = {
	[1243] = 21562, -- 인내
	[14752] = 27681, -- 정신
	[976] = 27683, -- 암흑 보호
	[1459] = 23028, -- 지능
	[1126] = 21849, -- 야생
	[19740] = 25782, -- 힘
	[19977] = 25890, -- 빛
	[19742] = 25894, -- 지혜
	[1038] = 25895, -- 구원
	[20217] = 25898, -- 왕
	[20911] = 25899, -- 성역

  [5242] = 2048,
  [6192] = 2048,
  [11549] = 2048,
  [11550] = 2048,
  [11551] = 2048,
  [25289] = 2048,
	--[1459] = 61316,	-- 신비한 총명함 = 달라란의 총명함
}

if IRF3.isClassic then
	wipe(sameBuffs)
	sameBuffs = classicSameBuffs
end

IRF3.raidBuffData = {
	same = sameBuffs,
	link = {
		--[469] = 6673,		-- 지휘의 외침 = 전투의 외침
		--[20217] = 19740,	-- 왕의 축복 = 힘의 축복
	},
}

local linkRaidBuffs = {}

local raidBuffInfo = {}

local function addRaidBuff(tbl, spellId, isClassBuff)
	local spellName, _, spellIcon = GetSpellInfo(spellId)
	if spellName then
		if isClassBuff then
			for _, v in ipairs(tbl) do
				if v.id == spellId then
					return true
				end
			end
		end
		tinsert(tbl, {
			id = spellId,
			name = spellName,
			--rank = spellRank,
			icon = spellIcon,
			passive = IsPassiveSpell(spellId)
		})
		raidBuffInfo[spellId] = tbl[#tbl]
		return true
	end
	return nil
end

for i, spellIds in pairs(raidBuffs) do
	local n = {}
	for _, spellId in ipairs(spellIds) do
		addRaidBuff(n, spellId)
	end
	raidBuffs[i] = n
end

for spellId, mask in pairs(classRaidBuffs) do

	for _, i in ipairs(mask) do

		if #raidBuffs[i] > 0 and addRaidBuff(raidBuffs[i], spellId, true) and not raidBuffInfo[spellId].passive then
			if sameBuffs[spellId] then
				addRaidBuff(raidBuffs[i], sameBuffs[spellId], true)
			end
		else
			classRaidBuffs[spellId] = nil
			sameBuffs[spellId] = nil
			break
		end
	end
end

if not next(classRaidBuffs) then return end

local currentRaidBuffs, checkMask, buffCnt, buff, buff2 = {}, {}, 0

local function showBuffIcon(icon, texture)
	icon:SetSize(IRF3.db.units.buffIconSize, IRF3.db.units.buffIconSize)
	icon:SetTexture(texture)
	icon:Show()
end

local function hideBuffIcon(icon)
	icon:SetSize(0.001, 0.001)
	icon:Hide()
end

local function getBuff(unit, spellId)
	if InvenRaidFrames3Member_UnitAura(raidBuffInfo[spellId].name, unit, "HELPFUL") then
		for _, i in ipairs(classRaidBuffs[spellId]) do
			checkMask[i] = raidBuffInfo[spellId]
		end
	elseif IRF3.isClassic and sameBuffs[spellId] and AuraUtil.FindAuraByName(raidBuffInfo[sameBuffs[spellId]].name, unit, "HELPFUL") then
		for _, i in ipairs(classRaidBuffs[spellId]) do
			checkMask[i] = raidBuffInfo[sameBuffs[spellId]]
			higherspellId=sameBuffs[spellId]
		end
	else
		for _, i in ipairs(classRaidBuffs[spellId]) do
			if checkMask[i] == nil then
				checkMask[i] = false
				for _, v in ipairs(raidBuffs[i]) do
					if InvenRaidFrames3Member_UnitAura(v.name, unit) then -- , v.rank
						checkMask[i] = v
						break
					end
				end
				if checkMask[i] == false then
					spellId = nil
					break
				end
			elseif checkMask[i] == false then
				spellId = nil
				break
			end
		end
	end
	return spellId, higherspellId
end

local function isMyParty(arg1, arg2)
	if not arg1 or not arg2 then
		return true
	end
	if select(3, GetRaidRosterInfo(arg1)) == select(3, GetRaidRosterInfo(arg2)) then
		return true
	end
	return false
end

InvenRaidFrames3Member_UpdateBuffs = function(self, isFullUpdate, updatedAuras)

if isFullUpdate ~= nil then 
--print("Buff UNIT_AURA_check:")
--print(isFullUpdate)
end


	if not UnitIsPlayer(self.displayedUnit) or UnitInVehicle(self.displayedUnit) then 
		hideBuffIcon(self["buffIcon1"])
		hideBuffIcon(self["buffIcon2"])
		return 
	end
	
	local isMyParty = (not IRF3.isClassic) or (IRF3.isClassic and IRF3.isWOTLK ) or (playerClass ~= "WARRIOR") or isMyParty(UnitInRaid("player"), UnitInRaid(self.displayedUnit))	-- 클래식 전사 외침 파티만 적용
 


	
	-- 걸러버리면 버프표시가 안되어있을 때 버프 주문이 들어오기전까지 안걸려있다고 표시를 못해줌.
	if not isFullUpdate and updatedAuras then
		local isFindSpell = false
		for i = 1, updatedAuras and #updatedAuras or 0 do	-- 자신의 공대 버프가 아니면 패스
			if updatedAuras[i].isHelpful == true then
				for spellId in pairs(currentRaidBuffs) do
					if updatedAuras[i].spellId == spellId then
						isFindSpell = true
						break
					end
				end
				if isFindSpell then
					break
				end
			end
		end		
		if isFindSpell == false then
			return
		end
	end

	wipe(checkMask)
	buffCnt = 0
	for spellId in pairs(currentRaidBuffs) do
		buff,higherspellId = getBuff(self.displayedUnit, spellId)

		if not isMyParty then
		elseif InvenRaidFrames3CharDB.classBuff2[spellId] == 1 then
			-- 버프가 없을 때 표시
			if not buff then
				buffCnt = buffCnt + 1
				showBuffIcon(self["buffIcon"..buffCnt], raidBuffInfo[spellId].icon)
			end
		elseif InvenRaidFrames3CharDB.classBuff2[spellId] == 2 then
			-- 버프가 있을 때 표시
			if buff then
				buffCnt = buffCnt + 1

--상급/일반 축복아이콘구분
				if higherspellId then --상급주문을 사용한 경우라면 상급아이콘을 사용
					_,_,higherspellIcon = GetSpellInfo(higherspellId)
					showBuffIcon(self["buffIcon"..buffCnt], higherspellIcon)
				else
					showBuffIcon(self["buffIcon"..buffCnt], raidBuffInfo[spellId].icon)
				end

--				showBuffIcon(self["buffIcon"..buffCnt], raidBuffInfo[spellId].icon)
			end
		end
		if buffCnt == 2 then return end
	end

	for i = buffCnt + 1, 2 do
		hideBuffIcon(self["buffIcon"..i])
	end
end

local function updateClassBuff()
	wipe(currentRaidBuffs)
	wipe(linkRaidBuffs)
	for spellId, mask in pairs(classRaidBuffs) do
		if IsSpellKnown(spellId) then
			currentRaidBuffs[spellId] = mask
		else
			for nextSpellId, sameId in pairs(sameBuffs) do
				if IsSpellKnown(nextSpellId) then
					currentRaidBuffs[nextSpellId] = mask
					break
				end
			end
		end
	end
	for a, b in pairs(IRF3.raidBuffData.link) do
		if currentRaidBuffs[a] and currentRaidBuffs[b] then
			linkRaidBuffs[a] = b
			currentRaidBuffs[a] = nil
			currentRaidBuffs[b] = nil
		end
	end
	if not IRF3.SetupClassBuff then
		for _, header in pairs(IRF3.headers) do
			for _, member in pairs(header.members) do
				if member:IsVisible() then
					InvenRaidFrames3Member_UpdateBuffs(member)
				end
			end
		end
	end
end

local handler = CreateFrame("Frame")
handler:SetScript("OnEvent", updateClassBuff)
if wowtocversion and wowtocversion > 90000 then
	handler:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
	handler:RegisterEvent("PLAYER_TALENT_UPDATE")
end
handler:RegisterEvent("PLAYER_ENTERING_WORLD")
handler:RegisterEvent("LEARNED_SPELL_IN_TAB")

function IRF3:SetupClassBuff()
	self.SetupClassBuff = nil
	InvenRaidFrames3CharDB.classBuff = nil
	InvenRaidFrames3CharDB.classBuff2 = type(InvenRaidFrames3CharDB.classBuff2) == "table" and InvenRaidFrames3CharDB.classBuff2 or {}
	for spellId in pairs(InvenRaidFrames3CharDB.classBuff2) do
		if not classRaidBuffs[spellId] then
			InvenRaidFrames3CharDB.classBuff2[spellId] = nil
		end
	end
	for spellId in pairs(classRaidBuffs) do
		if raidBuffInfo[spellId].passive then
			InvenRaidFrames3CharDB.classBuff2[spellId] = nil
		elseif InvenRaidFrames3CharDB.classBuff2[spellId] ~= 0 and InvenRaidFrames3CharDB.classBuff2[spellId] ~= 1 and InvenRaidFrames3CharDB.classBuff2[spellId] ~= 2 then
			if spellId == 203538 or spellId == 203539 then	-- 성기사 예외 처리
				InvenRaidFrames3CharDB.classBuff2[spellId] = 2
			else
				InvenRaidFrames3CharDB.classBuff2[spellId] = 1
			end
		end
	end
	updateClassBuff()
end