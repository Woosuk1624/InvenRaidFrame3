local _G = _G
local IRF3 = _G[...]
--local UnitThreatSituation = _G.UnitThreatSituation
local UnitCanAttack = _G.UnitCanAttack
local GetNumGroupMembers = _G.GetNumGroupMembers
local GetNumSubgroupMembers = _G.GetNumSubgroupMembers
local PlaySoundFile = _G.PlaySoundFile
local SM = LibStub("LibSharedMedia-3.0")

local aggroUnits = {}

local function hasAggroPlayer(unit)
	if not aggroUnits then return false end
	
	for k in pairs(aggroUnits) do
    if aggroUnits[k] == unit then
      return true
    end
	end
	return false
end
local function hasAggroMob(unit)
	if not aggroUnits then return false end
	
	for k in pairs(aggroUnits) do
    if k == unit then
      return true
    end
	end
	return false
end



 

local function lostAggroPlayer(unit)
	if not aggroUnits then return false end
	
	for k in pairs(aggroUnits) do
    if aggroUnits[k] == unit then
      aggroUnits[k] = nil
    end
	end
	return
end

 



local function hasAggroValue(unit)
---jws
if not aggroUnits then return false end
	return (UnitThreatSituation(unit) or 0)
end


function InvenRaidFrames3Member_UpdateThreat(self)
  if not self.unit then return end
	self.hasAggro = hasAggroPlayer(UnitGUID(self.unit))
	self.hasAggroValue = hasAggroValue(self.displayedUnit)
end

local function AddAggro(mobGUID, playerGUID) end

local aggro = CreateFrame("Frame", nil, IRF3)
aggro.timer, aggro.check2 = 0, false
aggro:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE")
aggro:RegisterEvent("PLAYER_REGEN_ENABLED")
aggro:RegisterEvent("NAME_PLATE_UNIT_ADDED")
aggro:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
aggro:RegisterEvent("UNIT_TARGET")
aggro:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

aggro:SetScript("OnEvent", function(self, event, arg1)

if event == "PLAYER_REGEN_ENABLED" then

    if not aggroUnits then return end
    local selfCheck = false
    --print("init")
    for k in pairs(aggroUnits) do

      --print(tostring(k) .. " = " .. tostring(aggroUnits[k]))
      if selfCheck == false and aggroUnits[k] == UnitGUID("player") then

        AddAggro(k, nil) --플레이어 본인이 어그로대상인데 전투가 풀렸으면->어그로 삭제
        selfCheck = true
      end
    end
 
    
	aggroUnits = {}
 

	IRF3:UpdateThreatSituation()

elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then

    local timestamp, eventType, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, extraArg1, extraArg2, extraArg3, extraArg4, extraArg5, extraArg6, extraArg7, extraArg8, extraArg9, extraArg10 = CombatLogGetCurrentEventInfo()
    if eventType == "UNIT_DIED" then
      if bit.band(destFlags, COMBATLOG_OBJECT_TYPE_PLAYER) > 0 or bit.band(destFlags, COMBATLOG_OBJECT_TYPE_PET) > 0 then
        lostAggroPlayer(destGUID) --아군이 죽었을때 삭제
      else
 
        AddAggro(destGUID, nil) --적군이 죽었을때 삭제

--기타사항으로 인해 어글대상이 없어졌을 경우 어글표시 남음(소환수 사라지거나, 정배되었던 아군이 정배해제되거나등?)
 
	   
      end
    elseif eventType == "SWING_DAMAGE" or eventType == "RANGE_DAMAGE" or eventType == "SPELL_DAMAGE" then --or eventType == "ENVIRONMENTAL_DAMAGE"


      if sourceGUID and bit.band(sourceFlags, COMBATLOG_OBJECT_REACTION_FRIENDLY) == 0 and bit.band(destFlags, COMBATLOG_OBJECT_REACTION_FRIENDLY) > 0 then

AddAggro(sourceGUID, destGUID) --적이 공격할때 추가
 
      end

    end 
-- 대상 선택으로 어그로 체크하기.

elseif event == "UNIT_TARGET" then  
    local mob = arg1
    if not UnitIsEnemy("player", arg1) then 
      mob = arg1.."target"
    end
    local target = mob.."target"
    if not UnitExists(mob) then return end  -- mob은 nil 체크. target은 nil 가능
    if not UnitIsEnemy("player", mob) then return end
    if not UnitCanAttack("player", mob) then return end
    if not UnitIsDeadOrGhost(mob) then
      AddAggro(UnitGUID(mob), UnitGUID(target))
    end

elseif event == "NAME_PLATE_UNIT_ADDED" then

    local unit = arg1
    if not unit then return end
    local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
    if not nameplate then return end
    local nameplateTarget = unit.."target"
    if not unit:match("nameplate%d?$") then return end
    if UnitIsPlayer(unit) then return end -- prevent coloring player nameplates
    if not UnitGUID(nameplateTarget) then return end
    AddAggro(UnitGUID(unit), UnitGUID(nameplateTarget))


--[[
	elseif event == "NAME_PLATE_UNIT_REMOVED" then
   -- aggroUnits[UnitGUID(arg1)] = nil
		IRF3:UpdateThreatSituation()
	--]]
	end
end)

aggro.Update = function()
  local self = aggro 
  self.check1 = self.check2
  self.check2 = hasAggroPlayer(UnitGUID("player"))
  if IRF3.db.units.aggroType == 2 then
    self.trigger = true
  elseif IRF3.db.units.aggroType == 3 then
    self.trigger = IsInGroup()
  elseif IRF3.db.units.aggroType == 4 then
    self.trigger = IsInRaid()
  else
    self.trigger = nil
  end
  if self.trigger and self.check1 ~= self.check2 then
    if self.check1 then
      if IRF3.db.units.aggroLost ~= "None" then
        PlaySoundFile(SM:Fetch("sound", IRF3.db.units.aggroLost))
      end
    elseif IRF3.db.units.aggroGain ~= "None" then
      PlaySoundFile(SM:Fetch("sound", IRF3.db.units.aggroGain))
    end
  end
end

AddAggro = function(mobGUID, playerGUID)
  local oldPlayer = nil
  if aggroUnits[mobGUID] then
    oldPlayer = aggroUnits[mobGUID]
  end
  aggroUnits[mobGUID] = playerGUID

  if oldPlayer ~= playerGUID then
    IRF3:UpdateThreatSituation()
	end
-- 자신의 소리 알림 체크
  if (playerGUID == UnitGUID("player") or oldPlayer == UnitGUID("player") or playerGUID == nil) and IRF3.db then  --
    aggro.Update()
  end
  
end

-- 체력바로 어그로 체크하기.
-- 체력바를 켜놓을 때만 반응한다. 근접 몹일 경우 어그로가 끌려도 한대 치기전까지 체크가 안되지만 이걸 사용하면 바로 확인됨.
-- 죽은뒤에 한 틱 체크되는 문제 있음.
local function UpdatAggroFlashThreat(nameplate)
--	if not InCombatLockdown() then return end

	local unit = nameplate.unit
	local nameplateTarget = nameplate.unit.."target"


	if not unit then return end
	if not unit:match("nameplate%d?$") then return end


	if UnitIsPlayer(unit) then return end -- 플레이어의 이름바는 패스---정배일경우는 필요함.
	local nameplate2 = C_NamePlate.GetNamePlateForUnit(unit)
	if not nameplate2 or UnitGUID(nameplateTarget) == nil then return end -- 대상이 있나?

	if UnitIsDeadOrGhost(unit) then return end  -- 대상이 죽었는가?

--print(UnitIsEnemy("player", unit))
	if not UnitIsEnemy("player", unit) then return end  -- 적인가?

	if aggroUnits and aggroUnits[UnitGUID(unit)] and aggroUnits[UnitGUID(unit)] == UnitGUID(nameplateTarget) then
    return
  end
  --print("nameplate "..UnitGUID(unit))

  AddAggro(UnitGUID(unit), UnitGUID(nameplateTarget))
end

hooksecurefunc("CompactUnitFrame_UpdateInRange", UpdatAggroFlashThreat)

--
