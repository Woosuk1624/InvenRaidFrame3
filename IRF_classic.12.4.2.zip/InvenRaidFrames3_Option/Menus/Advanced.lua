﻿local IRF3 = InvenRaidFrames3
local Option = IRF3.optionFrame
local LBO = LibStub("LibBlueOption-1.0")

function Option:CreateAdvancedMenu(menu, parent)
	self.CreateAdvancedMenu = nil
--	local addonsLinkList = { "사용 안함", "Grid2", "Lime", "Plexus" }
--	menu.addonsLink = LBO:CreateWidget("DropDown", parent, "연동", "OmniCD 와 비슷한 기능의 애드온과 연동하기 위해 애드온 이름을 추가합니다.(해당 애드온이 꺼져 있어야 합니다.) 설정 후 수동으로 UI Load 가 필요합니다. 채팅창에 /reload 를 쳐주세요.", nil, nil, true,
--		function() return not IRF3:GetAddonlinkDB() and 1 or IRF3:GetAddonlinkDB() == 0 and 1 or IRF3:GetAddonlinkDB(), addonsLinkList end,
--		function(v)
--			IRF3:SetAddonlinkDB(v)
--		end
--	)
--	menu.addonsLink:SetPoint("TOPLEFT", 5, -5)
	
	
--	menu.addonsLinkText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
--	menu.addonsLinkText:SetPoint("TOPLEFT", 175, -30)
--	menu.addonsLinkText:SetText("|cffffffff( 변경 후 채팅창에 ".. ORANGE_FONT_COLOR_CODE.."/reload|cffffffff를 입력하세요. )")
	

	menu.enableFadeIn = LBO:CreateWidget("CheckBox", parent, "주문 타이머 동적 표시", "주문 타이머와 약화 효과의 점점 커지는 연출을 활성화 합니다.", nil, nil, true,
		function() return IRF3.db.enableFadeIn end,
		function(v)
			IRF3.db.enableFadeIn = v
			
		end
	)
	menu.enableFadeIn:SetPoint("TOPLEFT", 5, -5)
--	menu.enableFadeIn:SetPoint("TOP", menu.addonsLink, "BOTTOM", 0, 0)
--
	menu.FadeInFrequency = LBO:CreateWidget("Slider", parent, "동적 애니메이션 업데이트 주기(0.01초)", "단위가 짧을 수록 부드럽게 표현되나 성능에 영향을 미칠 수 있습니다.", nil, nil, true,
		function() return IRF3.db.FadeInFrequency, 1, 10, 1, "" end,
		function(v)
			IRF3.db.FadeInFrequency = v

		end
	)
	menu.FadeInFrequency:SetPoint("LEFT", menu.enableFadeIn, "RIGHT", 10, 0)
--



	menu.enableSpellTimerType1 = LBO:CreateWidget("CheckBox", parent, "주문 타이머 폰트 겹치기", "주문 타이머의 아이콘과 타이머 폰트의 위치를 겹치게 합니다.", nil, nil, true,
		function() return IRF3.db.enableSpellTimerType1 end,
		function(v)
			IRF3.db.enableSpellTimerType1 = v
			IRF3:UpdateSpellTimerFont()
			IRF3:UpdateSpellTimerWidth()
		end
	)
	menu.enableSpellTimerType1:SetPoint("TOP", menu.enableFadeIn, "BOTTOM", 0, 0)

	menu.SpellTimerFontColor = LBO:CreateWidget("ColorPicker", parent, "폰트 색상", "주문타이머의 폰트 색상을 지정합니다..", nil, disable, true,
		function() return IRF3.db.units.SpellTimerFontColor[1], IRF3.db.units.SpellTimerFontColor[2], IRF3.db.units.SpellTimerFontColor[3] end,
		function(r, g, b)
			IRF3.db.units.SpellTimerFontColor[1], IRF3.db.units.SpellTimerFontColor[2], IRF3.db.units.SpellTimerFontColor[3] = r, g, b
			IRF3:UpdateSpellTimerFont()

		end
	)
	menu.SpellTimerFontColor:SetPoint("TOP", menu.enableSpellTimerType1, "BOTTOM", 0, 0)

	menu.SpellTimerOtherFontColor = LBO:CreateWidget("ColorPicker", parent, "폰트 색상(타인)", "타인이 시전한 주문타이머의 폰트 색상을 지정합니다..", nil, disable, true,
		function() return IRF3.db.units.SpellTimerOtherFontColor[1], IRF3.db.units.SpellTimerOtherFontColor[2], IRF3.db.units.SpellTimerOtherFontColor[3] end,
		function(r, g, b)
			IRF3.db.units.SpellTimerOtherFontColor[1], IRF3.db.units.SpellTimerOtherFontColor[2], IRF3.db.units.SpellTimerOtherFontColor[3] = r, g, b
			IRF3:UpdateSpellTimerFont()

		end
	)
	menu.SpellTimerOtherFontColor:SetPoint("LEFT", menu.SpellTimerFontColor, "RIGHT", 0, 0)



	menu.SpellTimerCountColor = LBO:CreateWidget("ColorPicker", parent, "중첩 횟수 색상", "주문타이머의 스킬중첩 색상을 지정합니다. 폰트 겹치기 사용시 남은 시간과 중첩을 구별하는데 용이합니다.", nil, disable, true,
		function() return IRF3.db.units.SpellTimerCountColor[1], IRF3.db.units.SpellTimerCountColor[2], IRF3.db.units.SpellTimerCountColor[3] end,
		function(r, g, b)
			IRF3.db.units.SpellTimerCountColor[1], IRF3.db.units.SpellTimerCountColor[2], IRF3.db.units.SpellTimerCountColor[3] = r, g, b
			IRF3:UpdateSpellTimerFont()

		end
	)
	menu.SpellTimerCountColor:SetPoint("LEFT", menu.SpellTimerOtherFontColor, "RIGHT", 0, 0)
 


	menu.enableTankFrame = LBO:CreateWidget("CheckBox", parent, "방어전담 프레임 표시", "방어전담으로 지정한 플레이어들을 별도 프레임에 표시합니다.", nil, nil, true,
		function() return IRF3.db.enableTankFrame end,
		function(v)
			IRF3.db.enableTankFrame = v
			Option:SetOption("enableTankFrame", v)
 
			
		end
	)
	menu.enableTankFrame:SetPoint("TOP", menu.SpellTimerFontColor, "BOTTOM", 0, 0)

	menu.enableInstantHealth = LBO:CreateWidget("CheckBox", parent, "Instant Health사용하기", "기본 블리자드 이벤트이외에 전투로그를 반영하여 실시간 체력수치를 적용합니다.CPU사용량이 증가합니다.", nil, nil, true,
		function() return IRF3.db.enableInstantHealth end,
		function(v)
			IRF3.db.enableInstantHealth = v
			StaticPopupDialogs["IRFPROFILE"] = {
			text = "UI 다시 불러오기를해야 적용됩니다. 다시 불러오시겠습니까?",
			button1="Yes", button2="No", timeout=30, whileDead=1, showAlert=enable, hideOnEscape=1,
			OnAccept=function()   ReloadUI() end,
			OnCancel=function()   end
			}
			StaticPopup_Show("IRFPROFILE")
		end
	)
	menu.enableInstantHealth:SetPoint("TOP", menu.enableTankFrame, "BOTTOM", 0, 0)

 	if not InvenRaidFrames3DB.CPUUsage then InvenRaidFrames3DB.CPUUsage = false end
	menu.CPUUsage = LBO:CreateWidget("CheckBox", parent, "CPU사용량 표시", "좌클릭: 라이브러리 사용/해제 , 우클릭: 감추기/열기", nil, nil, true,
 		function() return InvenRaidFrames3DB.CPUUsage end,
 		function(v)
 			InvenRaidFrames3DB.CPUUsage = v
 			InvenRaidFrames3CPUUsage_Toggle()
 		end
 	)
 	menu.CPUUsage:SetPoint("TOP", menu.enableInstantHealth, "BOTTOM", 0, -10)

end